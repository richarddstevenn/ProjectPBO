package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

public class MyGdxGame extends ApplicationAdapter {
	private SpriteBatch batch;
	private Texture backgroundTexture;
	private Bird bird;
	private Array<Eagle> eagles;
	private Array<Naga> nagas;
	private Array<Heart> hearts;
	private int lives;
	private BitmapFont font;
	private long lastSpawnTime;
	private Texture liveHeart;
	private Texture pause;
	Boolean ispaused;
	private Sound backSound;

	@Override
	public void create() {
		batch = new SpriteBatch();
		bird = new Bird();
		eagles = new Array<>();
		nagas = new Array<>();
		hearts = new Array<>();
		font = new BitmapFont();
		backSound = Gdx.audio.newSound(Gdx.files.internal("gameAwal.mp3"));
		bird.create();
		lives = 3;
		lastSpawnTime = TimeUtils.nanoTime();
		pause = new Texture("pause.png");
		liveHeart = new Texture("hati.gif");
		backgroundTexture = new Texture("flappybackground.jpg");
		ispaused = false;
		Gdx.input.setInputProcessor(new tap());
	}

	@Override
	//method
	public void render() {
		//digunakan untuk pause
		if (ispaused){
			return;
		}
		//menggambar background,burung,naga,elang,dan hati
		batch.begin();
		batch.draw(backgroundTexture, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		batch.end();
		bird.render();
		for (Naga naga : nagas){
			naga.render();
		}
		for (Eagle eagle : eagles) {
			eagle.render();
		}
		for (Heart heart : hearts){
			heart.render();
		}
		batch.begin();
		// ini untuk menampilkan jumlah nyawa yang dimiliki
		batch.draw(liveHeart,10,430);
		font.draw(batch, " " + lives, 40, 452);
		// ini untuk menampilkan tombol pause
		batch.draw(pause,565,410);
		batch.end();

		// Spawn musuh dan hati dan lagu pada waktu tertentu
		if (TimeUtils.nanoTime() - lastSpawnTime > 1000000000) {
			spawnNaga();
			spawnEagle();
			spawnHeart();
			backSound.play();
			lastSpawnTime = TimeUtils.nanoTime();
		}
	}

	@Override
	public void dispose() {
		// agar gambar burung, naga, elang, hati, background, pause, font untuk nyawa hilang ketika game selesai dimainkan
		batch.dispose();
		bird.dispose();
		for (Naga naga : nagas) {
			naga.dispose();
		}
		for (Eagle eagle : eagles) {
			eagle.dispose();
		}
		for (Heart heart : hearts){
			heart.dispose();
		}
		font.dispose();
		backgroundTexture.dispose();
		pause.dispose();
	}

	interface kegiatan {
		// sebagai class yang menyediakan method-method tanpa implementasi di didalamnya dan
		// dapat digunakan pada kelas yang mengimplementasikannya
		void create();
		void render();
		void dispose();
	}

	class Bird implements kegiatan {
		//declare gambar oobjek,sound collect, dan sound tabrak
		private Texture birdTexture;
		private Rectangle bird;
		private Sound crashSound;
		private Sound collectSound;

		// Untuk membuat objek burung
		public void create() {
			birdTexture = new Texture("burung baik.gif");
			bird = new Rectangle();
			// ketika burung menabrak objek musuh akan mengeluarkan suara
			crashSound = Gdx.audio.newSound(Gdx.files.internal("doorhit.mp3"));
			// ketika burung menabrak objek hati akan mngeluarkan suara
			collectSound  = Gdx.audio.newSound(Gdx.files.internal("collect.mp3"));
			bird.x = 0;
			bird.y = 200;
			bird.width = 40;
			bird.height = 40;
		}

		public void render() {
			// ini untuk menggerakan ke bawah
			if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
				bird.y -= 200 * Gdx.graphics.getDeltaTime();
			}
			// ini untuk menggerakan ke atas
			if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
				bird.y += 200 * Gdx.graphics.getDeltaTime();
			}
			// ini untuk menggerakan ke kanan
			if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
				bird.x += 200 * Gdx.graphics.getDeltaTime();
			}
			// ini untuk menggerakan ke kiri
			if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
				bird.x -= 200 * Gdx.graphics.getDeltaTime();
			}
			//letak agar burung tidak melebihi batas layar
			if (bird.y < 0) {
				bird.y = 0;
			}
			if (bird.y > 475 - 64) {
				bird.y = 475 - 64;
			}
			if (bird.x < 0) {
				bird.x = 0;
			}
			if (bird.x > 475 - 64) {
				bird.x = 475 - 64;
			}

			// Ketika menabrak objek musuh "Elang" akan mengurangi nyawa sebanyak 1
			for (Eagle eagle : eagles) {
				if (bird.overlaps(eagle.getRectangle())) {
					crashSound.play();
					lives--;
					eagles.removeValue(eagle, true);
					break;
				}
			}
			// Ketika menabrak objek musuh "Naga" akan mengurangi nyawa sebanyak 1
			for (Naga naga : nagas) {
				if (bird.overlaps(naga.getRectangle())) {
					crashSound.play();
					lives--;
					nagas.removeValue(naga, true);
					break;
				}
			}
			// Ketika menabrak objek hati akan menambah nyawa sebanyak 1
			for (Heart heart : hearts) {
				if (bird.overlaps(heart.getRectangle())) {
					collectSound.play();
					lives++;
					hearts.removeValue(heart, true);
					break;
				}
			}

			// Ketika nyawa yang dimiliki user 0, game akan selesai
			if (lives <= 0) {
				Gdx.app.exit();
			}
			// Ini untuk mengatur agar nyawa yang dimiliki maksimal 3
			if (lives >=3){
				lives = 3;
			}

			// Render bird
			batch.begin();
			batch.draw(birdTexture, bird.x, bird.y);
			batch.end();
		}
		// agar gambar burung dan backsound hilang ketika game selesai dimainkan

		public void dispose() {
			birdTexture.dispose();
			backSound.dispose();
		}
	}

	class Eagle extends character implements kegiatan {
		//mendclare gambar elang dan ukuran gambar
		public Eagle() {
			gambar = new Texture("elang2.gif");
			objek = new Rectangle();
			objek.width = 64;
			objek.height = 64;
		}

		//digunakan untuk overlaps
		public Rectangle getRectangle() {
			return objek;
		}

		@Override
		public void create() {

		}

		public void render () {
			//untuk mengatur kecepatan gerak dan arah gerakan eagle
			objek.x -= 200 * Gdx.graphics.getDeltaTime();
			if (objek.x + objek.getWidth() < 0) {
				//untuk menghapus objek eagle jika posisi dibawah 0
				eagles.removeValue(this,true);
			}

			batch.begin();
			batch.draw(gambar, objek.x, objek.y);
			batch.end();
		}

		public void dispose () {
			gambar.dispose();
		}
	}
	class Naga extends character implements kegiatan{
		//mendclare gambar naga dan ukuran gambar
		public Naga() {
			gambar= new Texture("naga.png");
			objek = new Rectangle();
			objek.width = 64;
			objek.height = 64;
		}

		public Rectangle getRectangle() {
			return objek;
		}

		@Override
		public void create() {
		}

		public void render () {
			//untuk mengatur kecepatan gerak dan arah gerakan naga
			objek.x -= 600 * Gdx.graphics.getDeltaTime();
			//untuk menghapus objek naga jika posisi dibawah 0
			if (objek.x + objek.getWidth() < 0) {
				nagas.removeValue(this, true);
			}

			batch.begin();
			batch.draw(gambar, objek.x, objek.y);
			batch.end();
		}

		public void dispose () {
			gambar.dispose();
		}
	}
	class Heart extends character {
		//mendclare gambar heart dan ukuran gambar
		public Heart() {
			gambar = new Texture("hati.gif");
			objek = new Rectangle();
			objek.width = 64;
			objek.height = 64;
		}

		public Rectangle getRectangle() {
			return objek;
		}

		public void render() {
			//untuk mengatur kecepatan gerak dan arah gerakan heart
			objek.x -= 200 * Gdx.graphics.getDeltaTime();

			if (objek.x + objek.getWidth() < 0) {
				//untuk menghapus objek heart jika posisi dibawah 0
				hearts.removeValue(this, true);
			}

			batch.begin();
			batch.draw(gambar, objek.x, objek.y);
			batch.end();
		}

		public void dispose() {
			gambar.dispose();
		}
	}
	// ini untuk spawn hati dan disimpan di array hearts
	private void spawnHeart() {
		Heart heart = new Heart();
		heart.objek.x = 800;
		heart.objek.y = MathUtils.random(0, 600 - 64);
		hearts.add(heart);
	}

	// ini untuk spawn eagle dan disimpan di array eagles
	private void spawnEagle() {
		Eagle eagle = new Eagle();
		eagle.objek.x = 800;
		eagle.objek.y = MathUtils.random(0, 600 - 64);
		eagles.add(eagle);
	}
	// ini untuk spawn naga dan disimpan di array nagas
	private void spawnNaga() {
		Naga naga = new Naga();
		naga.objek.x = 800;
		naga.objek.y = MathUtils.random(0, 600 - 64);
		nagas.add(naga);
	}
	//clas untuk tap icon pause
	class tap implements InputProcessor {
		@Override
		public boolean keyDown(int keycode) {
			return false;
		}

		@Override
		public boolean keyUp(int keycode) {
			return false;
		}

		@Override
		public boolean keyTyped(char character) {
			return false;
		}

		@Override
		public boolean touchDown(int screenX, int screenY, int pointer, int button) {
			float touchX = screenX;
			float touchY = Gdx.graphics.getHeight() - screenY;

			// Periksa apakah sentuhan terjadi di sekitar tombol pause sesuai dengan koordinat x dan y
			if (touchX >= 565 && touchX <= 565  + pause.getWidth() &&
					touchY >= 410 && touchY <= 410 + pause.getHeight()) {
				ispaused = !ispaused;
				return true;
			}
			return false;
		}

		@Override
		public boolean touchUp(int screenX, int screenY, int pointer, int button) {
			return false;
		}

		@Override
		public boolean touchDragged(int screenX, int screenY, int pointer) {
			return false;
		}

		@Override
		public boolean mouseMoved(int screenX, int screenY) {
			return false;
		}

		@Override
		public boolean scrolled(float amountX, float amountY) {
			return false;
		}
	}
	//class parent
	class character{
		public Texture gambar;
		public Rectangle objek;
	}
	//Class: Terdapat beberapa class seperti MyGdxGame, Bird, Eagle, Naga, Heart, tap, dan character.
	// Setiap class mewakili objek yang berbeda dalam permainan.
	//
	//Object: Setiap class dapat digunakan untuk membuat objek-objek yang memiliki atribut dan perilaku tertentu.
	// Contohnya adalah objek bird yang merupakan instansiasi dari class Bird.
	//
	//Inheritance: Terdapat penggunaan inheritance dalam class Eagle, Naga, Heart, dan character.
	// Class Eagle, Naga, dan Heart merupakan subclass dari class character.
	//
	//Encapsulation: Setiap class menggunakan encapsulation dengan mendefinisikan atribut dan perilaku sebagai variabel
	// dan method non-public (private atau protected) untuk menjaga keamanan data dan pengaturan akses ke objek.
	//
	//Polymorphism: Polymorphism dapat dilihat dalam penggunaan method render() pada class Bird, Eagle, Naga, dan Heart.
	// Meskipun method dengan nama yang sama digunakan di berbagai class, namun fungsi method tersebut berbeda tergantung
	// pada class yang menggunakanya.
	//
	//Abstraction: Terdapat interface kegiatan yang menyediakan method-method tanpa implementasi yang dapat digunakan oleh class-class yang mengimplementasikannya.
	// Ini memungkinkan adanya polimorfisme dan penggunaan metode dengan nama yang sama namun fungsi yang berbeda.
	//
	//Association: Terdapat hubungan antara class MyGdxGame dengan class Bird, Eagle, Naga, dan Heart.
	// Class MyGdxGame menggunakan objek-objek dari class-class tersebut dalam implementasi permainan.
}



