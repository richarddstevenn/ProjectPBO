package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

public class MyGdxGame extends ApplicationAdapter {
	private SpriteBatch batch;
	private Texture backgroundTexture;
	private Bird bird;
	private Array<Eagle> eagles;
	private Array<Naga> nagas;
	private Array<Heart> hearts;
	private int lives;
	private BitmapFont font;
	private long lastSpawnTime;
	private Texture liveHeart;
	private Texture pause;
	Boolean ispaused;

	@Override
	public void create() {
		batch = new SpriteBatch();
		bird = new Bird();
		eagles = new Array<>();
		nagas = new Array<>();
		hearts = new Array<>();
		font = new BitmapFont();
		bird.create();
		lives = 3;
		lastSpawnTime = TimeUtils.nanoTime();
		pause = new Texture("pause.png");
		liveHeart = new Texture("hati.gif");
		backgroundTexture = new Texture("flappybackground.jpg");
		ispaused = false;
		Gdx.input.setInputProcessor(new tap());
	}

	@Override
	public void render() {
		if (ispaused){
			return;
		}
		ScreenUtils.clear(0, 0, 0.2f, 0);
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		batch.draw(backgroundTexture, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		batch.end();
		bird.render();
		for (Naga naga : nagas){
			naga.render();
		}
		for (Eagle eagle : eagles) {
			eagle.render();
		}
		for (Heart heart : hearts){
			heart.render();
		}
		batch.begin();
		batch.draw(liveHeart,10,430);
		font.draw(batch, " " + lives, 40, 452);
		batch.draw(pause,565,410);
		batch.end();

		// Spawn enemies periodically
		if (TimeUtils.nanoTime() - lastSpawnTime > 1000000000) {
			spawnNaga();
			spawnEagle();
			spawnHeart();
			lastSpawnTime = TimeUtils.nanoTime();
		}
	}

	@Override
	public void dispose() {
		batch.dispose();
		bird.dispose();
		for (Naga naga : nagas) {
			naga.dispose();
		}
		for (Eagle eagle : eagles) {
			eagle.dispose();
		}
		for (Heart heart : hearts){
			heart.dispose();
		}
		font.dispose();
		backgroundTexture.dispose();
		pause.dispose();
	}

	interface kegiatan{
		void create();
		void render();
		void dispose();
	}

	class Bird implements kegiatan {
		private Texture birdTexture;
		private Rectangle bird;

		public void create() {
			birdTexture = new Texture("burung baik.gif");
			bird = new Rectangle();
			bird.x = 0;
			bird.y = 200;
			bird.width = 64;
			bird.height = 64;
		}

		public void render() {
			if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
				bird.y -= 200 * Gdx.graphics.getDeltaTime();
			}
			if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
				bird.y += 200 * Gdx.graphics.getDeltaTime();
			}
			if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
				bird.x += 200 * Gdx.graphics.getDeltaTime();
			}
			if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
				bird.x -= 200 * Gdx.graphics.getDeltaTime();
			}
			if (bird.y < 0) {
				bird.y = 0;
			}
			if (bird.y > 475 - 64) {
				bird.y = 475 - 64;
			}
			if (bird.x < 0) {
				bird.x = 0;
			}
			if (bird.x > 475 - 64) {
				bird.x = 475 - 64;
			}

			// Check collision with enemies
			for (Eagle eagle : eagles) {
				if (bird.overlaps(eagle.getRectangle())) {
					lives--;
					eagles.removeValue(eagle, true);
					break;
				}
			}
			for (Naga naga : nagas) {
				if (bird.overlaps(naga.getRectangle())) {
					lives--;
					nagas.removeValue(naga, true);
					break;
				}

			}
			for (Heart heart : hearts) {
				if (bird.overlaps(heart.getRectangle())) {
					lives++;
					hearts.removeValue(heart, true);
					break;
				}
			}

			// Check game over condition
			if (lives <= 0) {
				Gdx.app.exit();
			}
			if (lives >=3){
				lives = 3;
			}

			// Render bird
			batch.begin();
			batch.draw(birdTexture, bird.x, bird.y);
			batch.end();
		}

		public void dispose() {
			birdTexture.dispose();
		}
	}

	class Eagle implements kegiatan {
		private Texture enemyTexture;
		private Rectangle enemy;

		public Eagle() {
			enemyTexture = new Texture("elang2.gif");
			enemy = new Rectangle();
			enemy.width = 64;
			enemy.height = 64;
		}

		public Rectangle getRectangle() {
			return enemy;
		}

		@Override
		public void create() {

		}

		public void render () {
			enemy.x -= 200 * Gdx.graphics.getDeltaTime();

			if (enemy.x + enemy.getWidth() < 0) {
				eagles.removeValue(this, true);
			}

			batch.begin();
			batch.draw(enemyTexture, enemy.x, enemy.y);
			batch.end();
		}

		public void dispose () {
			enemyTexture.dispose();
		}
	}
	class Naga implements kegiatan{
		private Texture enemyTexture;
		private Rectangle enemy;

		public Naga() {
			enemyTexture = new Texture("naga.png");
			enemy = new Rectangle();
			enemy.width = 64;
			enemy.height = 64;
		}

		public Rectangle getRectangle() {
			return enemy;
		}

		@Override
		public void create() {

		}

		public void render () {
			enemy.x -= 400 * Gdx.graphics.getDeltaTime();

			if (enemy.x + enemy.getWidth() < 0) {
				nagas.removeValue(this, true);
			}

			batch.begin();
			batch.draw(enemyTexture, enemy.x, enemy.y);
			batch.end();
		}

		public void dispose () {
			enemyTexture.dispose();
		}
	}
	class Heart {
		private Texture heartTexture;
		private Rectangle heartKelas;

		public Heart() {
			heartTexture = new Texture("hati.gif");
			heartKelas = new Rectangle();
			heartKelas.width = 64;
			heartKelas.height = 64;
		}

		public Rectangle getRectangle() {
			return heartKelas;
		}

		public void render() {
			heartKelas.x -= 200 * Gdx.graphics.getDeltaTime();

			if (heartKelas.x + heartKelas.getWidth() < 0) {
				hearts.removeValue(this, true);
			}

			batch.begin();
			batch.draw(heartTexture, heartKelas.x, heartKelas.y);
			batch.end();
		}

		public void dispose() {
			heartTexture.dispose();
		}
	}
	private void spawnHeart() {
		Heart heart = new Heart();
		heart.heartKelas.x = 800;
		heart.heartKelas.y = MathUtils.random(0, 600 - 64);
		hearts.add(heart);
	}


	private void spawnEagle() {
		Eagle eagle = new Eagle();
		eagle.enemy.x = 800;
		eagle.enemy.y = MathUtils.random(0, 600 - 64);
		eagles.add(eagle);
	}
	private void spawnNaga() {
		Naga naga = new Naga();
		naga.enemy.x = 800;
		naga.enemy.y = MathUtils.random(0, 600 - 64);
		nagas.add(naga);
	}
	class tap implements InputProcessor {
		@Override
		public boolean keyDown(int keycode) {
			return false;
		}

		@Override
		public boolean keyUp(int keycode) {
			return false;
		}

		@Override
		public boolean keyTyped(char character) {
			return false;
		}

		@Override
		public boolean touchDown(int screenX, int screenY, int pointer, int button) {
			float touchX = screenX;
			float touchY = Gdx.graphics.getHeight() - screenY;

			// Periksa apakah sentuhan terjadi di sekitar tombol pause
			if (touchX >= 565 && touchX <= 565  + pause.getWidth() &&
					touchY >= 410 && touchY <= 410 + pause.getHeight()) {
				ispaused = !ispaused;
				return true;
			}
			return false;
		}

		@Override
		public boolean touchUp(int screenX, int screenY, int pointer, int button) {
			return false;
		}

		@Override
		public boolean touchDragged(int screenX, int screenY, int pointer) {
			return false;
		}

		@Override
		public boolean mouseMoved(int screenX, int screenY) {
			return false;
		}

		@Override
		public boolean scrolled(float amountX, float amountY) {
			return false;
		}
	}
}



